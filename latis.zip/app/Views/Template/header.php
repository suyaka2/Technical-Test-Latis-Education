<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title><?= $title ?></title>

    <!-- Custom fonts for this template-->
    <link href="/assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="/assets/css/sb-admin-2.min.css" rel="stylesheet">
    <link href="/assets/vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
    <link href="/assets/css/sweetalert2.min.css" rel="stylesheet">

    <!-- <link href="https://cdn.datatables.net/v/dt/dt-3.0.4/datatables.min.css" rel="stylesheet"> -->
    <link href="https://cdn.datatables.net/v/bs4/jszip-3.10.1/dt-3.0.4/b-4.0.3/datatables.min.css" rel="stylesheet" integrity="sha384-YHZFKZV/UkOQ8VFZqMQKEe5bcuOTwj2Hvq3NvzfQWNno1el3aRe7jxPDvbtoB9S4" crossorigin="anonymous">

</head>
<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

                <!-- End of Topbar -->





